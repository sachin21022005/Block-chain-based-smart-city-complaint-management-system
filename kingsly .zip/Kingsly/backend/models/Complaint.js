const mongoose = require('mongoose');

const complaintSchema = mongoose.Schema({
    user: { 
        type: mongoose.Schema.Types.ObjectId, 
        ref: 'User',
        required: true 
    },
    userEmail: { type: String, required: true },
    userName: { type: String },
    title: { type: String, required: true },
    description: { type: String, required: true },
    district: { type: String, required: true },
    area: { type: String, required: true },
    address: { type: String, required: true },
    status: {
        type: String,
        enum: ['Pending', 'Assigned', 'Working', 'Resolved', 'Rejected'],
        default: 'Pending'
    },
    assignedTo: { 
        type: mongoose.Schema.Types.ObjectId, 
        ref: 'User',
        default: null 
    },
    assignedOfficerName: { type: String },
    location: {
        lat: Number,
        lng: Number
    },
    imageId: { type: mongoose.Schema.Types.ObjectId },
    imageUrl: { type: String },
    resolutionImageId: { type: mongoose.Schema.Types.ObjectId },
    resolutionImageUrl: { type: String },
    remarks: { type: String },
    statusHistory: [{
        status: String,
        changedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
        changedAt: { type: Date, default: Date.now },
        remarks: String,
        imageId: { type: mongoose.Schema.Types.ObjectId }
    }]
}, {
    timestamps: true
});

module.exports = mongoose.model('Complaint', complaintSchema);
