const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const dotenv = require('dotenv');

dotenv.config();

// Import models
const User = require('../models/User');
const Complaint = require('../models/Complaint');

const seedData = async () => {
    try {
        await mongoose.connect(process.env.MONGO_URI);
        console.log('Connected to MongoDB');

        // Clear existing data
        await User.deleteMany({});
        await Complaint.deleteMany({});
        console.log('Cleared existing data');

        // Create admin
        const admin = await User.create({
            name: 'Super Admin',
            email: 'admin@smartcomplaint.com',
            password: 'admin123',
            role: 'admin',
            isVerified: true
        });
        console.log('Admin created:', admin.email);

        // Create officers
        const officers = await User.create([
            {
                name: 'Officer Kumar',
                email: 'kumar@smartcomplaint.com',
                password: 'officer123',
                role: 'officer',
                district: 'Chennai',
                isVerified: true
            },
            {
                name: 'Officer Ravi',
                email: 'ravi@smartcomplaint.com',
                password: 'officer123',
                role: 'officer',
                district: 'Coimbatore',
                isVerified: true
            },
            {
                name: 'Officer Meena',
                email: 'meena@smartcomplaint.com',
                password: 'officer123',
                role: 'officer',
                district: 'Madurai',
                isVerified: true
            }
        ]);
        console.log('Officers created:', officers.length);

        // Create sample citizen
        const citizen = await User.create({
            name: 'John Citizen',
            email: 'citizen@example.com',
            password: 'citizen123',
            role: 'citizen',
            phone: '9876543210',
            isVerified: true
        });
        console.log('Citizen created:', citizen.email);

        // Create sample complaints
        const complaints = await Complaint.create([
            {
                user: citizen._id,
                userEmail: citizen.email,
                userName: citizen.name,
                title: 'Road Damage in T Nagar',
                description: 'Large pothole on main road causing accidents',
                district: 'Chennai',
                area: 'T Nagar',
                address: '123 Main Street, T Nagar',
                location: { lat: 13.0418, lng: 80.2341 },
                status: 'Pending'
            },
            {
                user: citizen._id,
                userEmail: citizen.email,
                userName: citizen.name,
                title: 'Street Light Not Working',
                description: 'Street light not working for 2 weeks',
                district: 'Chennai',
                area: 'Anna Nagar',
                address: '456 Second Avenue, Anna Nagar',
                location: { lat: 13.0850, lng: 80.2101 },
                status: 'Assigned',
                assignedTo: officers[0]._id,
                assignedOfficerName: officers[0].name
            },
            {
                user: citizen._id,
                userEmail: citizen.email,
                userName: citizen.name,
                title: 'Garbage Not Collected',
                description: 'Garbage not collected for a week',
                district: 'Coimbatore',
                area: 'RS Puram',
                address: '789 Third Street, RS Puram',
                location: { lat: 11.0168, lng: 76.9558 },
                status: 'Working',
                assignedTo: officers[1]._id,
                assignedOfficerName: officers[1].name
            }
        ]);
        console.log('Complaints created:', complaints.length);

        console.log('\n=== Seed Data Complete ===');
        console.log('\nLogin Credentials:');
        console.log('Admin: admin@smartcomplaint.com / admin123');
        console.log('Officer: kumar@smartcomplaint.com / officer123');
        console.log('Citizen: citizen@example.com / citizen123');

        process.exit(0);
    } catch (error) {
        console.error('Error seeding data:', error);
        process.exit(1);
    }
};

seedData();
