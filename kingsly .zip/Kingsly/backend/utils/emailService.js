const nodemailer = require('nodemailer');

const BACKEND_URL = process.env.BACKEND_URL || 'http://localhost:8000';

// Create transporter
const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS
    }
});

// Verify transporter connection
transporter.verify((error, success) => {
    if (error) {
        console.log('Email service error:', error);
    } else {
        console.log('Email service is ready');
    }
});

// Send email function
const sendEmail = async (to, subject, html) => {
    try {
        const mailOptions = {
            from: `"Smart Complaint System" <${process.env.EMAIL_FROM}>`,
            to,
            subject,
            html
        };
        
        const info = await transporter.sendMail(mailOptions);
        console.log('Email sent:', info.messageId);
        return { success: true, messageId: info.messageId };
    } catch (error) {
        console.error('Email error:', error);
        return { success: false, error: error.message };
    }
};

// Helper to generate image HTML section
const getImageSection = (imageId, label = 'Complaint Image') => {
    if (!imageId) return '';
    return `
        <div style="margin: 15px 0;">
            <p><strong>${label}:</strong></p>
            <img src="${BACKEND_URL}/api/image/${imageId}" 
                 alt="${label}" 
                 style="max-width: 100%; max-height: 300px; border-radius: 8px; border: 1px solid #e5e7eb;" />
        </div>
    `;
};

// Email templates
const emailTemplates = {
    // Welcome email after registration
    welcome: (name) => ({
        subject: 'Welcome to Smart Complaint System',
        html: `
            <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
                <h2 style="color: #2563eb;">Welcome to Smart Complaint System!</h2>
                <p>Hello ${name},</p>
                <p>Thank you for registering with our Smart Complaint System. You can now:</p>
                <ul>
                    <li>File complaints about civic issues</li>
                    <li>Track your complaint status</li>
                    <li>Receive updates on resolution</li>
                </ul>
                <p>Start by logging in to your account and filing your first complaint.</p>
                <a href="${process.env.FRONTEND_URL}/login" style="display: inline-block; background: #2563eb; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">Login Now</a>
                <p style="margin-top: 20px; color: #666;">Best regards,<br>Smart Complaint System Team</p>
            </div>
        `
    }),
    
    // Password reset email
    resetPassword: (name, resetLink) => ({
        subject: 'Password Reset Request - Smart Complaint System',
        html: `
            <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
                <h2 style="color: #2563eb;">Password Reset Request</h2>
                <p>Hello ${name},</p>
                <p>You have requested to reset your password. Click the button below to set a new password:</p>
                <a href="${resetLink}" style="display: inline-block; background: #2563eb; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin: 20px 0;">Reset Password</a>
                <p>This link will expire in 1 hour.</p>
                <p>If you did not request this, please ignore this email.</p>
                <p style="margin-top: 20px; color: #666;">Best regards,<br>Smart Complaint System Team</p>
            </div>
        `
    }),
    
    // Complaint assigned notification
    complaintAssigned: (citizenName, complaintTitle, officerName, complaintId, imageId = null) => ({
        subject: `Your Complaint Has Been Assigned - ${complaintTitle}`,
        html: `
            <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
                <h2 style="color: #2563eb;">Complaint Assigned</h2>
                <p>Hello ${citizenName},</p>
                <p>Your complaint has been assigned to an officer for resolution.</p>
                <div style="background: #f3f4f6; padding: 15px; border-radius: 8px; margin: 20px 0;">
                    <p><strong>Complaint ID:</strong> ${complaintId}</p>
                    <p><strong>Title:</strong> ${complaintTitle}</p>
                    <p><strong>Assigned Officer:</strong> ${officerName}</p>
                    <p><strong>Status:</strong> <span style="color: #f59e0b;">Assigned</span></p>
                </div>
                ${getImageSection(imageId, 'Your Complaint Image')}
                <p>You will receive updates as the officer works on resolving your complaint.</p>
                <a href="${process.env.FRONTEND_URL}/dashboard" style="display: inline-block; background: #2563eb; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">Track Complaint</a>
                <p style="margin-top: 20px; color: #666;">Best regards,<br>Smart Complaint System Team</p>
            </div>
        `
    }),
    
    // Status update notification with images
    statusUpdate: (citizenName, complaintTitle, newStatus, remarks, complaintId, originalImageId = null, resolutionImageId = null) => ({
        subject: `Complaint Status Updated - ${complaintTitle}`,
        html: `
            <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
                <h2 style="color: #2563eb;">Complaint Status Updated</h2>
                <p>Hello ${citizenName},</p>
                <p>The status of your complaint has been updated.</p>
                <div style="background: #f3f4f6; padding: 15px; border-radius: 8px; margin: 20px 0;">
                    <p><strong>Complaint ID:</strong> ${complaintId}</p>
                    <p><strong>Title:</strong> ${complaintTitle}</p>
                    <p><strong>New Status:</strong> <span style="color: ${getStatusColor(newStatus)}; font-weight: bold;">${newStatus}</span></p>
                    ${remarks ? `<p><strong>Remarks:</strong> ${remarks}</p>` : ''}
                </div>
                ${getImageSection(originalImageId, 'Original Complaint Image')}
                ${resolutionImageId ? getImageSection(resolutionImageId, 'Resolution/Update Image by Officer') : ''}
                <a href="${process.env.FRONTEND_URL}/dashboard" style="display: inline-block; background: #2563eb; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">View Details</a>
                <p style="margin-top: 20px; color: #666;">Best regards,<br>Smart Complaint System Team</p>
            </div>
        `
    })
};

// Helper function for status colors
function getStatusColor(status) {
    const colors = {
        'Pending': '#f59e0b',
        'Assigned': '#3b82f6',
        'Working': '#8b5cf6',
        'Resolved': '#10b981',
        'Rejected': '#ef4444'
    };
    return colors[status] || '#666';
}

// Export functions
module.exports = {
    sendEmail,
    emailTemplates,
    
    // Convenience functions
    sendWelcomeEmail: async (email, name) => {
        const template = emailTemplates.welcome(name);
        return sendEmail(email, template.subject, template.html);
    },
    
    sendResetPasswordEmail: async (email, name, resetToken) => {
        const resetLink = `${process.env.FRONTEND_URL}/reset-password/${resetToken}`;
        const template = emailTemplates.resetPassword(name, resetLink);
        return sendEmail(email, template.subject, template.html);
    },
    
    sendComplaintAssignedEmail: async (email, citizenName, complaintTitle, officerName, complaintId, imageId = null) => {
        const template = emailTemplates.complaintAssigned(citizenName, complaintTitle, officerName, complaintId, imageId);
        return sendEmail(email, template.subject, template.html);
    },
    
    sendStatusUpdateEmail: async (email, citizenName, complaintTitle, newStatus, remarks, complaintId, originalImageId = null, resolutionImageId = null) => {
        const template = emailTemplates.statusUpdate(citizenName, complaintTitle, newStatus, remarks, complaintId, originalImageId, resolutionImageId);
        return sendEmail(email, template.subject, template.html);
    }
};
