const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const mongoose = require('mongoose');
const Complaint = require('../models/Complaint');
const User = require('../models/User');
const upload = require('../utils/gridfsStorage');
const { sendComplaintAssignedEmail, sendStatusUpdateEmail } = require('../utils/emailService');

// Auth middleware
const protect = async (req, res, next) => {
    try {
        const token = req.headers.authorization?.split(' ')[1];
        if (!token) {
            return res.status(401).json({ message: 'Not authorized' });
        }

        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        req.user = await User.findById(decoded.id).select('-password');
        next();
    } catch (error) {
        res.status(401).json({ message: 'Not authorized' });
    }
};

// @route   POST /api/complaints
// @desc    Create a new complaint
router.post('/', protect, upload.single('image'), async (req, res) => {
    try {
        const { title, description, district, area, address, lat, lng } = req.body;

        const complaintData = {
            user: req.user._id,
            userEmail: req.user.email,
            userName: req.user.name,
            title,
            description,
            district,
            area,
            address,
            location: {
                lat: parseFloat(lat) || 0,
                lng: parseFloat(lng) || 0
            },
            status: 'Pending',
            statusHistory: [{
                status: 'Pending',
                changedBy: req.user._id,
                remarks: 'Complaint registered'
            }]
        };

        // If image was uploaded
        if (req.file) {
            complaintData.imageId = req.file.id;
            complaintData.imageUrl = `/api/image/${req.file.id}`;
        }

        const complaint = await Complaint.create(complaintData);
        res.status(201).json(complaint);
    } catch (error) {
        console.error(error);
        res.status(400).json({ message: error.message });
    }
});

// @route   GET /api/complaints
// @desc    Get complaints (filtered by role)
router.get('/', protect, async (req, res) => {
    try {
        let query = {};

        // Filter based on user role
        if (req.user.role === 'citizen') {
            query.user = req.user._id;
        } else if (req.user.role === 'officer') {
            query.assignedTo = req.user._id;
        }
        // Admin can see all

        const complaints = await Complaint.find(query)
            .populate('user', 'name email')
            .populate('assignedTo', 'name email district')
            .sort({ createdAt: -1 });

        res.json(complaints);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// @route   GET /api/complaints/all
// @desc    Get all complaints (Admin only)
router.get('/all', protect, async (req, res) => {
    try {
        if (req.user.role !== 'admin') {
            return res.status(403).json({ message: 'Not authorized' });
        }

        const complaints = await Complaint.find()
            .populate('user', 'name email')
            .populate('assignedTo', 'name email district')
            .sort({ createdAt: -1 });

        res.json(complaints);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// @route   GET /api/complaints/stats
// @desc    Get complaint statistics
router.get('/stats', protect, async (req, res) => {
    try {
        let matchQuery = {};

        if (req.user.role === 'citizen') {
            matchQuery.user = req.user._id;
        } else if (req.user.role === 'officer') {
            matchQuery.assignedTo = req.user._id;
        }

        const stats = await Complaint.aggregate([
            { $match: matchQuery },
            {
                $group: {
                    _id: '$status',
                    count: { $sum: 1 }
                }
            }
        ]);

        const total = await Complaint.countDocuments(matchQuery);
        const statObj = {
            total,
            Pending: 0,
            Assigned: 0,
            Working: 0,
            Resolved: 0,
            Rejected: 0
        };

        stats.forEach(s => {
            statObj[s._id] = s.count;
        });

        res.json(statObj);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// @route   GET /api/complaints/:id
// @desc    Get single complaint
router.get('/:id', protect, async (req, res) => {
    try {
        const complaint = await Complaint.findById(req.params.id)
            .populate('user', 'name email phone')
            .populate('assignedTo', 'name email district');

        if (!complaint) {
            return res.status(404).json({ message: 'Complaint not found' });
        }

        res.json(complaint);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// @route   PUT /api/complaints/:id/assign
// @desc    Assign complaint to officer (Admin only)
router.put('/:id/assign', protect, async (req, res) => {
    try {
        if (req.user.role !== 'admin') {
            return res.status(403).json({ message: 'Not authorized' });
        }

        const { officerId } = req.body;
        const officer = await User.findById(officerId);

        if (!officer || officer.role !== 'officer') {
            return res.status(400).json({ message: 'Invalid officer' });
        }

        const complaint = await Complaint.findById(req.params.id);
        if (!complaint) {
            return res.status(404).json({ message: 'Complaint not found' });
        }

        complaint.assignedTo = officerId;
        complaint.assignedOfficerName = officer.name;
        complaint.status = 'Assigned';
        complaint.statusHistory.push({
            status: 'Assigned',
            changedBy: req.user._id,
            remarks: `Assigned to ${officer.name}`
        });

        await complaint.save();

        // Send email to citizen with complaint image
        await sendComplaintAssignedEmail(
            complaint.userEmail,
            complaint.userName || 'Citizen',
            complaint.title,
            officer.name,
            complaint._id,
            complaint.imageId  // Include complaint image in email
        );

        res.json(complaint);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: error.message });
    }
});

// @route   PUT /api/complaints/:id/status
// @desc    Update complaint status (Officer) - supports image upload for resolution
router.put('/:id/status', protect, upload.single('resolutionImage'), async (req, res) => {
    try {
        const { status, remarks } = req.body;

        const complaint = await Complaint.findById(req.params.id);
        if (!complaint) {
            return res.status(404).json({ message: 'Complaint not found' });
        }

        // Check authorization
        if (req.user.role === 'officer' && complaint.assignedTo?.toString() !== req.user._id.toString()) {
            return res.status(403).json({ message: 'Not authorized to update this complaint' });
        }

        const oldStatus = complaint.status;
        complaint.status = status;
        if (remarks) complaint.remarks = remarks;

        // If officer uploaded a resolution image
        if (req.file) {
            complaint.resolutionImageId = req.file.id;
            complaint.resolutionImageUrl = `/api/image/${req.file.id}`;
        }

        complaint.statusHistory.push({
            status,
            changedBy: req.user._id,
            remarks: remarks || `Status changed from ${oldStatus} to ${status}`,
            imageId: req.file ? req.file.id : null
        });

        await complaint.save();

        // Send email to citizen with image information
        await sendStatusUpdateEmail(
            complaint.userEmail,
            complaint.userName || 'Citizen',
            complaint.title,
            status,
            remarks,
            complaint._id,
            complaint.imageId,  // Original complaint image
            req.file ? req.file.id : null  // Resolution image
        );

        res.json(complaint);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: error.message });
    }
});

// @route   DELETE /api/complaints/:id
// @desc    Delete complaint
router.delete('/:id', protect, async (req, res) => {
    try {
        const complaint = await Complaint.findById(req.params.id);
        if (!complaint) {
            return res.status(404).json({ message: 'Complaint not found' });
        }

        // Only admin or complaint owner can delete
        if (req.user.role !== 'admin' && complaint.user.toString() !== req.user._id.toString()) {
            return res.status(403).json({ message: 'Not authorized' });
        }

        await complaint.deleteOne();
        res.json({ message: 'Complaint deleted' });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

module.exports = router;
