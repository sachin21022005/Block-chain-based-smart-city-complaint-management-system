import React, { useState, useEffect } from 'react';
import Sidebar from '../../components/Sidebar';
import { complaintsAPI } from '../../services/api';
import { toast } from 'react-toastify';
import { FaClipboardList, FaCheckCircle, FaClock, FaSpinner, FaTimes, FaCamera, FaImage } from 'react-icons/fa';
import '../../components/Sidebar.css';
import '../citizen/Dashboard.css';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:8000';

const OfficerDashboard = () => {
  const [complaints, setComplaints] = useState([]);
  const [stats, setStats] = useState({
    total: 0,
    Assigned: 0,
    Working: 0,
    Resolved: 0
  });
  const [loading, setLoading] = useState(true);
  const [selectedComplaint, setSelectedComplaint] = useState(null);
  const [updateModal, setUpdateModal] = useState(false);
  const [newStatus, setNewStatus] = useState('');
  const [remarks, setRemarks] = useState('');
  const [updating, setUpdating] = useState(false);
  const [resolutionImage, setResolutionImage] = useState(null);
  const [imagePreview, setImagePreview] = useState(null);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [complaintsRes, statsRes] = await Promise.all([
        complaintsAPI.getAll(),
        complaintsAPI.getStats()
      ]);
      setComplaints(complaintsRes.data);
      setStats(statsRes.data);
    } catch (error) {
      toast.error('Failed to fetch data');
    } finally {
      setLoading(false);
    }
  };

  const getStatusBadge = (status) => {
    const badges = {
      Pending: 'badge-pending',
      Assigned: 'badge-assigned',
      Working: 'badge-working',
      Resolved: 'badge-resolved',
      Rejected: 'badge-rejected'
    };
    return badges[status] || 'badge-pending';
  };

  const openUpdateModal = (complaint) => {
    setSelectedComplaint(complaint);
    setNewStatus(complaint.status);
    setRemarks('');
    setResolutionImage(null);
    setImagePreview(null);
    setUpdateModal(true);
  };

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setResolutionImage(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleUpdateStatus = async () => {
    if (!newStatus) {
      toast.error('Please select a status');
      return;
    }

    setUpdating(true);
    try {
      // Use FormData to support image upload
      const formData = new FormData();
      formData.append('status', newStatus);
      formData.append('remarks', remarks);
      if (resolutionImage) {
        formData.append('resolutionImage', resolutionImage);
      }

      await complaintsAPI.updateStatusWithImage(selectedComplaint._id, formData);
      toast.success('Status updated successfully');
      setUpdateModal(false);
      setResolutionImage(null);
      setImagePreview(null);
      fetchData();
    } catch (error) {
      toast.error(error.response?.data?.message || 'Failed to update status');
    } finally {
      setUpdating(false);
    }
  };

  if (loading) {
    return (
      <div className="dashboard-layout">
        <Sidebar />
        <main className="main-content">
          <div className="loading-container">
            <div className="spinner"></div>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="dashboard-layout">
      <Sidebar />
      <main className="main-content">
        <div className="page-header">
          <h1>Officer Dashboard</h1>
          <p>Manage your assigned complaints</p>
        </div>

        {/* Stats Cards */}
        <div className="stats-grid">
          <div className="stat-card">
            <div className="stat-icon total">
              <FaClipboardList />
            </div>
            <div className="stat-info">
              <h3>{stats.total}</h3>
              <p>Total Assigned</p>
            </div>
          </div>
          <div className="stat-card">
            <div className="stat-icon pending">
              <FaClock />
            </div>
            <div className="stat-info">
              <h3>{stats.Assigned}</h3>
              <p>New Assignments</p>
            </div>
          </div>
          <div className="stat-card">
            <div className="stat-icon working">
              <FaSpinner />
            </div>
            <div className="stat-info">
              <h3>{stats.Working}</h3>
              <p>In Progress</p>
            </div>
          </div>
          <div className="stat-card">
            <div className="stat-icon resolved">
              <FaCheckCircle />
            </div>
            <div className="stat-info">
              <h3>{stats.Resolved}</h3>
              <p>Resolved</p>
            </div>
          </div>
        </div>

        {/* Complaints Table */}
        <div className="card">
          <div className="card-header">
            <h3>Assigned Complaints</h3>
          </div>
          <div className="table-container">
            {complaints.length === 0 ? (
              <div className="empty-state">
                <FaClipboardList className="empty-icon" />
                <h3>No Assignments</h3>
                <p>You don't have any complaints assigned yet.</p>
              </div>
            ) : (
              <table className="data-table">
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>Title</th>
                    <th>Citizen</th>
                    <th>District</th>
                    <th>Status</th>
                    <th>Date</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  {complaints.map((complaint) => (
                    <tr key={complaint._id}>
                      <td><code>{complaint._id.slice(-8)}</code></td>
                      <td>
                        <div className="complaint-title">
                          {complaint.imageId && (
                            <img 
                              src={`${API_URL}/api/image/${complaint.imageId}`} 
                              alt="" 
                              className="complaint-thumb"
                            />
                          )}
                          <span>{complaint.title}</span>
                        </div>
                      </td>
                      <td>{complaint.userName || complaint.userEmail}</td>
                      <td>{complaint.district} - {complaint.area}</td>
                      <td>
                        <span className={`badge ${getStatusBadge(complaint.status)}`}>
                          {complaint.status}
                        </span>
                      </td>
                      <td>{new Date(complaint.createdAt).toLocaleDateString()}</td>
                      <td>
                        <button 
                          className="btn btn-sm btn-primary"
                          onClick={() => openUpdateModal(complaint)}
                        >
                          Update
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </div>

        {/* Update Status Modal */}
        {updateModal && (
          <div className="modal-overlay">
            <div className="modal-content">
              <div className="modal-header">
                <h3>Update Complaint Status</h3>
                <button className="modal-close" onClick={() => setUpdateModal(false)}>
                  <FaTimes />
                </button>
              </div>

              <div className="form-group">
                <label>Complaint</label>
                <p><strong>{selectedComplaint?.title}</strong></p>
                <p className="text-muted">{selectedComplaint?.description}</p>
                {selectedComplaint?.imageId && (
                  <div style={{ marginTop: '10px' }}>
                    <label>Original Complaint Image:</label>
                    <img 
                      src={`${API_URL}/api/image/${selectedComplaint.imageId}`} 
                      alt="Complaint" 
                      style={{ maxWidth: '100%', maxHeight: '150px', borderRadius: '8px', marginTop: '5px' }}
                    />
                  </div>
                )}
              </div>

              <div className="form-group">
                <label>New Status</label>
                <select 
                  className="form-control"
                  value={newStatus}
                  onChange={(e) => setNewStatus(e.target.value)}
                >
                  <option value="Assigned">Assigned</option>
                  <option value="Working">Working</option>
                  <option value="Resolved">Resolved</option>
                  <option value="Rejected">Rejected</option>
                </select>
              </div>

              <div className="form-group">
                <label>Remarks</label>
                <textarea 
                  className="form-control"
                  placeholder="Add remarks or notes..."
                  value={remarks}
                  onChange={(e) => setRemarks(e.target.value)}
                  rows={3}
                />
              </div>

              <div className="form-group">
                <label>
                  <FaCamera style={{ marginRight: '5px' }} />
                  Upload Resolution/Update Image (Optional)
                </label>
                <div className="image-upload-area">
                  <input 
                    type="file" 
                    accept="image/*" 
                    onChange={handleImageChange}
                    id="resolutionImage"
                    style={{ display: 'none' }}
                  />
                  <label htmlFor="resolutionImage" className="btn btn-secondary" style={{ cursor: 'pointer', display: 'inline-flex', alignItems: 'center', gap: '5px' }}>
                    <FaImage /> {resolutionImage ? 'Change Image' : 'Select Image'}
                  </label>
                  {resolutionImage && (
                    <span style={{ marginLeft: '10px', color: '#666' }}>{resolutionImage.name}</span>
                  )}
                </div>
                {imagePreview && (
                  <div style={{ marginTop: '10px' }}>
                    <img 
                      src={imagePreview} 
                      alt="Preview" 
                      style={{ maxWidth: '100%', maxHeight: '150px', borderRadius: '8px' }}
                    />
                  </div>
                )}
              </div>

              <div className="modal-footer">
                <button 
                  className="btn btn-secondary"
                  onClick={() => setUpdateModal(false)}
                >
                  Cancel
                </button>
                <button 
                  className="btn btn-primary"
                  onClick={handleUpdateStatus}
                  disabled={updating}
                >
                  {updating ? 'Updating...' : 'Update Status'}
                </button>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
};

export default OfficerDashboard;
