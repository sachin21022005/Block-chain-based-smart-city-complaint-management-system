import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import Navbar from '../components/Navbar';
import { FaUser, FaUserShield, FaUserTie, FaCheckCircle, FaShieldAlt, FaChartLine } from 'react-icons/fa';
import './Home.css';

const Home = () => {
  const { user } = useAuth();

  const getDashboardLink = () => {
    if (!user) return '/login';
    switch (user.role) {
      case 'admin':
        return '/admin/dashboard';
      case 'officer':
        return '/officer/dashboard';
      default:
        return '/dashboard';
    }
  };

  return (
    <div className="home-page">
      <Navbar />
      
      {/* Hero Section */}
      <section className="hero">
        <div className="container">
          <h1>Smart Grievance Management System</h1>
          <p>
            Empowering citizens with a transparent, accountable, and efficient 
            complaint management system for a better community.
          </p>
          <div className="hero-buttons">
            <Link to={user ? getDashboardLink() : "/register"} className="btn btn-primary btn-lg">
              Get Started
            </Link>
            <Link to="/login" className="btn btn-outline btn-lg">
              File a Complaint
            </Link>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="features">
        <div className="container">
          <h2 className="section-title">Why Choose Us?</h2>
          <div className="features-grid">
            <div className="feature-card">
              <div className="feature-icon">
                <FaCheckCircle />
              </div>
              <h3>Easy Complaint Filing</h3>
              <p>Simple and intuitive interface to file complaints with location marking and image upload.</p>
            </div>
            <div className="feature-card">
              <div className="feature-icon">
                <FaChartLine />
              </div>
              <h3>Real-time Tracking</h3>
              <p>Track your complaint status in real-time and receive email notifications on updates.</p>
            </div>
            <div className="feature-card">
              <div className="feature-icon">
                <FaShieldAlt />
              </div>
              <h3>Secure & Transparent</h3>
              <p>Your data is secure and the entire process is transparent and accountable.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Role Cards */}
      <section className="role-section">
        <div className="container">
          <h2 className="section-title">Access Portal</h2>
          <div className="role-cards">
            <div className="role-card">
              <div className="role-icon citizen-icon">
                <FaUser />
              </div>
              <h3>Citizen Portal</h3>
              <p>File complaints, track status, and upload evidence of issues in your area.</p>
              <Link to="/login" className="btn btn-primary">
                Login as Citizen
              </Link>
            </div>

            <div className="role-card">
              <div className="role-icon officer-icon">
                <FaUserShield />
              </div>
              <h3>Officer Portal</h3>
              <p>Manage assigned complaints, update status, and resolve issues efficiently.</p>
              <Link to="/login" className="btn btn-primary">
                Login as Officer
              </Link>
            </div>

            <div className="role-card">
              <div className="role-icon admin-icon">
                <FaUserTie />
              </div>
              <h3>Admin Portal</h3>
              <p>Oversee all complaints, manage officers, and view analytics.</p>
              <Link to="/login" className="btn btn-primary">
                Login as Admin
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="footer">
        <div className="container">
          <p>&copy; 2024 Smart Complaint System. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
};

export default Home;
