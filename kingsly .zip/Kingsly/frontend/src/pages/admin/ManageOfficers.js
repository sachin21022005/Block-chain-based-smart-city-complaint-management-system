import React, { useState, useEffect } from 'react';
import Sidebar from '../../components/Sidebar';
import { usersAPI } from '../../services/api';
import { toast } from 'react-toastify';
import { 
  FaUserPlus, 
  FaEdit, 
  FaTrash,
  FaTimes,
  FaUserShield
} from 'react-icons/fa';
import '../../components/Sidebar.css';
import '../citizen/Dashboard.css';

const ManageOfficers = () => {
  const [officers, setOfficers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editMode, setEditMode] = useState(false);
  const [selectedOfficer, setSelectedOfficer] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    district: '',
    phone: ''
  });
  const [saving, setSaving] = useState(false);

  const districts = ['Chennai', 'Coimbatore', 'Madurai', 'Trichy'];

  useEffect(() => {
    fetchOfficers();
  }, []);

  const fetchOfficers = async () => {
    try {
      const response = await usersAPI.getOfficers();
      setOfficers(response.data);
    } catch (error) {
      toast.error('Failed to fetch officers');
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const openAddModal = () => {
    setEditMode(false);
    setSelectedOfficer(null);
    setFormData({
      name: '',
      email: '',
      password: '',
      district: '',
      phone: ''
    });
    setShowModal(true);
  };

  const openEditModal = (officer) => {
    setEditMode(true);
    setSelectedOfficer(officer);
    setFormData({
      name: officer.name,
      email: officer.email,
      password: '',
      district: officer.district || '',
      phone: officer.phone || ''
    });
    setShowModal(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!formData.name || !formData.email || !formData.district) {
      toast.error('Please fill in all required fields');
      return;
    }

    if (!editMode && !formData.password) {
      toast.error('Password is required for new officers');
      return;
    }

    setSaving(true);
    try {
      if (editMode) {
        await usersAPI.update(selectedOfficer._id, formData);
        toast.success('Officer updated successfully');
      } else {
        await usersAPI.createOfficer(formData);
        toast.success('Officer created successfully');
      }
      setShowModal(false);
      fetchOfficers();
    } catch (error) {
      toast.error(error.response?.data?.message || 'Failed to save officer');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (officer) => {
    if (window.confirm(`Are you sure you want to delete ${officer.name}?`)) {
      try {
        await usersAPI.delete(officer._id);
        toast.success('Officer deleted successfully');
        fetchOfficers();
      } catch (error) {
        toast.error('Failed to delete officer');
      }
    }
  };

  if (loading) {
    return (
      <div className="dashboard-layout">
        <Sidebar />
        <main className="main-content">
          <div className="loading-container">
            <div className="spinner"></div>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="dashboard-layout">
      <Sidebar />
      <main className="main-content">
        <div className="page-header">
          <h1>Manage Officers</h1>
          <p>Add, edit or remove officers from the system</p>
        </div>

        <div className="quick-actions">
          <button className="btn btn-primary" onClick={openAddModal}>
            <FaUserPlus /> Add New Officer
          </button>
        </div>

        <div className="card">
          <div className="card-header">
            <h3>Officers List</h3>
          </div>
          <div className="table-container">
            {officers.length === 0 ? (
              <div className="empty-state">
                <FaUserShield className="empty-icon" />
                <h3>No Officers</h3>
                <p>No officers have been added yet. Click the button above to add one.</p>
              </div>
            ) : (
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>District</th>
                    <th>Phone</th>
                    <th>Created</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {officers.map((officer) => (
                    <tr key={officer._id}>
                      <td>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                          <div className="user-avatar" style={{ width: '36px', height: '36px', fontSize: '14px' }}>
                            {officer.name?.charAt(0).toUpperCase()}
                          </div>
                          {officer.name}
                        </div>
                      </td>
                      <td>{officer.email}</td>
                      <td>{officer.district || '-'}</td>
                      <td>{officer.phone || '-'}</td>
                      <td>{new Date(officer.createdAt).toLocaleDateString()}</td>
                      <td>
                        <div className="action-btns">
                          <button 
                            className="btn btn-sm btn-secondary btn-icon"
                            onClick={() => openEditModal(officer)}
                            title="Edit"
                          >
                            <FaEdit />
                          </button>
                          <button 
                            className="btn btn-sm btn-danger btn-icon"
                            onClick={() => handleDelete(officer)}
                            title="Delete"
                          >
                            <FaTrash />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </div>

        {/* Add/Edit Modal */}
        {showModal && (
          <div className="modal-overlay">
            <div className="modal-content">
              <div className="modal-header">
                <h3>{editMode ? 'Edit Officer' : 'Add New Officer'}</h3>
                <button className="modal-close" onClick={() => setShowModal(false)}>
                  <FaTimes />
                </button>
              </div>

              <form onSubmit={handleSubmit}>
                <div className="form-group">
                  <label>Full Name *</label>
                  <input
                    type="text"
                    name="name"
                    className="form-control"
                    placeholder="Enter officer name"
                    value={formData.name}
                    onChange={handleChange}
                  />
                </div>

                <div className="form-group">
                  <label>Email *</label>
                  <input
                    type="email"
                    name="email"
                    className="form-control"
                    placeholder="Enter email address"
                    value={formData.email}
                    onChange={handleChange}
                    disabled={editMode}
                  />
                </div>

                {!editMode && (
                  <div className="form-group">
                    <label>Password *</label>
                    <input
                      type="password"
                      name="password"
                      className="form-control"
                      placeholder="Enter password"
                      value={formData.password}
                      onChange={handleChange}
                    />
                  </div>
                )}

                <div className="form-group">
                  <label>District *</label>
                  <select
                    name="district"
                    className="form-control"
                    value={formData.district}
                    onChange={handleChange}
                  >
                    <option value="">Select District</option>
                    {districts.map((district) => (
                      <option key={district} value={district}>{district}</option>
                    ))}
                  </select>
                </div>

                <div className="form-group">
                  <label>Phone</label>
                  <input
                    type="tel"
                    name="phone"
                    className="form-control"
                    placeholder="Enter phone number"
                    value={formData.phone}
                    onChange={handleChange}
                  />
                </div>

                <div className="modal-footer">
                  <button 
                    type="button"
                    className="btn btn-secondary"
                    onClick={() => setShowModal(false)}
                  >
                    Cancel
                  </button>
                  <button 
                    type="submit"
                    className="btn btn-primary"
                    disabled={saving}
                  >
                    {saving ? 'Saving...' : (editMode ? 'Update Officer' : 'Add Officer')}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </main>
    </div>
  );
};

export default ManageOfficers;
