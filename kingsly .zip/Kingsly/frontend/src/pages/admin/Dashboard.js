import React, { useState, useEffect } from 'react';
import Sidebar from '../../components/Sidebar';
import { complaintsAPI, usersAPI } from '../../services/api';
import { toast } from 'react-toastify';
import { 
  FaClipboardList, 
  FaCheckCircle, 
  FaClock, 
  FaUsers,
  FaTimes,
  FaUserTie
} from 'react-icons/fa';
import '../../components/Sidebar.css';
import '../citizen/Dashboard.css';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:8000';

const AdminDashboard = () => {
  const [complaints, setComplaints] = useState([]);
  const [officers, setOfficers] = useState([]);
  const [stats, setStats] = useState({
    total: 0,
    Pending: 0,
    Assigned: 0,
    Working: 0,
    Resolved: 0
  });
  const [loading, setLoading] = useState(true);
  const [assignModal, setAssignModal] = useState(false);
  const [selectedComplaint, setSelectedComplaint] = useState(null);
  const [selectedOfficer, setSelectedOfficer] = useState('');
  const [assigning, setAssigning] = useState(false);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [complaintsRes, statsRes, officersRes] = await Promise.all([
        complaintsAPI.getAllAdmin(),
        complaintsAPI.getStats(),
        usersAPI.getOfficers()
      ]);
      setComplaints(complaintsRes.data);
      setStats(statsRes.data);
      setOfficers(officersRes.data);
    } catch (error) {
      toast.error('Failed to fetch data');
    } finally {
      setLoading(false);
    }
  };

  const getStatusBadge = (status) => {
    const badges = {
      Pending: 'badge-pending',
      Assigned: 'badge-assigned',
      Working: 'badge-working',
      Resolved: 'badge-resolved',
      Rejected: 'badge-rejected'
    };
    return badges[status] || 'badge-pending';
  };

  const openAssignModal = (complaint) => {
    setSelectedComplaint(complaint);
    setSelectedOfficer(complaint.assignedTo?._id || '');
    setAssignModal(true);
  };

  const handleAssign = async () => {
    if (!selectedOfficer) {
      toast.error('Please select an officer');
      return;
    }

    setAssigning(true);
    try {
      await complaintsAPI.assign(selectedComplaint._id, selectedOfficer);
      toast.success('Complaint assigned successfully');
      setAssignModal(false);
      fetchData();
    } catch (error) {
      toast.error(error.response?.data?.message || 'Failed to assign complaint');
    } finally {
      setAssigning(false);
    }
  };

  if (loading) {
    return (
      <div className="dashboard-layout">
        <Sidebar />
        <main className="main-content">
          <div className="loading-container">
            <div className="spinner"></div>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="dashboard-layout">
      <Sidebar />
      <main className="main-content">
        <div className="page-header">
          <h1>Admin Dashboard</h1>
          <p>Manage all complaints and officers</p>
        </div>

        {/* Stats Cards */}
        <div className="stats-grid">
          <div className="stat-card">
            <div className="stat-icon total">
              <FaClipboardList />
            </div>
            <div className="stat-info">
              <h3>{stats.total}</h3>
              <p>Total Complaints</p>
            </div>
          </div>
          <div className="stat-card">
            <div className="stat-icon pending">
              <FaClock />
            </div>
            <div className="stat-info">
              <h3>{stats.Pending}</h3>
              <p>Pending</p>
            </div>
          </div>
          <div className="stat-card">
            <div className="stat-icon working">
              <FaUsers />
            </div>
            <div className="stat-info">
              <h3>{stats.Assigned + stats.Working}</h3>
              <p>In Progress</p>
            </div>
          </div>
          <div className="stat-card">
            <div className="stat-icon resolved">
              <FaCheckCircle />
            </div>
            <div className="stat-info">
              <h3>{stats.Resolved}</h3>
              <p>Resolved</p>
            </div>
          </div>
        </div>

        {/* Complaints Table */}
        <div className="card">
          <div className="card-header">
            <h3>All Complaints</h3>
          </div>
          <div className="table-container">
            {complaints.length === 0 ? (
              <div className="empty-state">
                <FaClipboardList className="empty-icon" />
                <h3>No Complaints</h3>
                <p>No complaints have been filed yet.</p>
              </div>
            ) : (
              <table className="data-table">
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>Title</th>
                    <th>Citizen</th>
                    <th>District</th>
                    <th>Status</th>
                    <th>Assigned To</th>
                    <th>Date</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  {complaints.map((complaint) => (
                    <tr key={complaint._id}>
                      <td><code>{complaint._id.slice(-8)}</code></td>
                      <td>
                        <div className="complaint-title">
                          {complaint.imageId && (
                            <img 
                              src={`${API_URL}/api/image/${complaint.imageId}`} 
                              alt="" 
                              className="complaint-thumb"
                            />
                          )}
                          <span>{complaint.title}</span>
                        </div>
                      </td>
                      <td>{complaint.userName || complaint.user?.name || 'Unknown'}</td>
                      <td>{complaint.district} - {complaint.area}</td>
                      <td>
                        <span className={`badge ${getStatusBadge(complaint.status)}`}>
                          {complaint.status}
                        </span>
                      </td>
                      <td>{complaint.assignedOfficerName || '-'}</td>
                      <td>{new Date(complaint.createdAt).toLocaleDateString()}</td>
                      <td>
                        <button 
                          className="btn btn-sm btn-primary"
                          onClick={() => openAssignModal(complaint)}
                        >
                          {complaint.assignedTo ? 'Reassign' : 'Assign'}
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </div>

        {/* Assign Officer Modal */}
        {assignModal && (
          <div className="modal-overlay">
            <div className="modal-content">
              <div className="modal-header">
                <h3>Assign Officer</h3>
                <button className="modal-close" onClick={() => setAssignModal(false)}>
                  <FaTimes />
                </button>
              </div>

              <div className="form-group">
                <label>Complaint</label>
                <p><strong>{selectedComplaint?.title}</strong></p>
                <p className="text-muted">District: {selectedComplaint?.district}</p>
              </div>

              <div className="form-group">
                <label>Select Officer</label>
                <select 
                  className="form-control"
                  value={selectedOfficer}
                  onChange={(e) => setSelectedOfficer(e.target.value)}
                >
                  <option value="">Select an officer</option>
                  {officers.map((officer) => (
                    <option key={officer._id} value={officer._id}>
                      {officer.name} - {officer.district}
                    </option>
                  ))}
                </select>
              </div>

              <div className="modal-footer">
                <button 
                  className="btn btn-secondary"
                  onClick={() => setAssignModal(false)}
                >
                  Cancel
                </button>
                <button 
                  className="btn btn-primary"
                  onClick={handleAssign}
                  disabled={assigning}
                >
                  <FaUserTie />
                  {assigning ? 'Assigning...' : 'Assign Officer'}
                </button>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
};

export default AdminDashboard;
