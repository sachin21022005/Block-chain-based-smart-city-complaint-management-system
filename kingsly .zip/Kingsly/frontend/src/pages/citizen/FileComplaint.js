import React, { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { MapContainer, TileLayer, Marker, useMapEvents } from 'react-leaflet';
import L from 'leaflet';
import Sidebar from '../../components/Sidebar';
import { complaintsAPI } from '../../services/api';
import { toast } from 'react-toastify';
import { FaUpload, FaMapMarkerAlt, FaTimes } from 'react-icons/fa';
import '../../components/Sidebar.css';
import './Dashboard.css';
import 'leaflet/dist/leaflet.css';

// Fix leaflet marker icons
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

const districtAreas = {
  Chennai: ['T Nagar', 'Velachery', 'Anna Nagar', 'Adyar', 'Tambaram'],
  Coimbatore: ['Gandhipuram', 'RS Puram', 'Peelamedu', 'Ukkadam'],
  Madurai: ['Anna Nagar', 'KK Nagar', 'Mattuthavani'],
  Trichy: ['Srirangam', 'Woraiyur', 'Thillai Nagar'],
};

const LocationMarker = ({ position, setPosition }) => {
  useMapEvents({
    click(e) {
      setPosition([e.latlng.lat, e.latlng.lng]);
    },
  });

  return position ? <Marker position={position} /> : null;
};

const FileComplaint = () => {
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    district: '',
    area: '',
    address: ''
  });
  const [position, setPosition] = useState(null);
  const [image, setImage] = useState(null);
  const [imagePreview, setImagePreview] = useState(null);
  const [loading, setLoading] = useState(false);
  const [agree, setAgree] = useState(false);
  const fileInputRef = useRef(null);
  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
    
    if (name === 'district') {
      setFormData({ ...formData, district: value, area: '' });
    }
  };

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        toast.error('Image must be less than 5MB');
        return;
      }
      setImage(file);
      setImagePreview(URL.createObjectURL(file));
    }
  };

  const removeImage = () => {
    setImage(null);
    setImagePreview(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!formData.title || !formData.description || !formData.district || !formData.area || !formData.address) {
      toast.error('Please fill in all required fields');
      return;
    }

    if (!agree) {
      toast.error('Please agree to the declaration');
      return;
    }

    setLoading(true);
    try {
      const data = new FormData();
      data.append('title', formData.title);
      data.append('description', formData.description);
      data.append('district', formData.district);
      data.append('area', formData.area);
      data.append('address', formData.address);
      
      if (position) {
        data.append('lat', position[0]);
        data.append('lng', position[1]);
      }
      
      if (image) {
        data.append('image', image);
      }

      await complaintsAPI.create(data);
      toast.success('Complaint submitted successfully!');
      navigate('/dashboard');
    } catch (error) {
      toast.error(error.response?.data?.message || 'Failed to submit complaint');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="dashboard-layout">
      <Sidebar />
      <main className="main-content">
        <div className="page-header">
          <h1>File a Complaint</h1>
          <p>Report issues in your locality</p>
        </div>

        <div className="card">
          <form onSubmit={handleSubmit}>
            <div className="form-grid">
              <div className="form-group">
                <label>Complaint Title *</label>
                <input
                  type="text"
                  name="title"
                  className="form-control"
                  placeholder="Brief title of your complaint"
                  value={formData.title}
                  onChange={handleChange}
                />
              </div>

              <div className="form-group">
                <label>District *</label>
                <select
                  name="district"
                  className="form-control"
                  value={formData.district}
                  onChange={handleChange}
                >
                  <option value="">Select District</option>
                  {Object.keys(districtAreas).map((district) => (
                    <option key={district} value={district}>{district}</option>
                  ))}
                </select>
              </div>

              <div className="form-group">
                <label>Area *</label>
                <select
                  name="area"
                  className="form-control"
                  value={formData.area}
                  onChange={handleChange}
                  disabled={!formData.district}
                >
                  <option value="">Select Area</option>
                  {formData.district && districtAreas[formData.district]?.map((area) => (
                    <option key={area} value={area}>{area}</option>
                  ))}
                </select>
              </div>
            </div>

            <div className="form-group">
              <label>Description *</label>
              <textarea
                name="description"
                className="form-control"
                placeholder="Describe the issue in detail..."
                value={formData.description}
                onChange={handleChange}
                rows={4}
              />
            </div>

            <div className="form-group">
              <label>Full Address *</label>
              <input
                type="text"
                name="address"
                className="form-control"
                placeholder="Enter the complete address"
                value={formData.address}
                onChange={handleChange}
              />
            </div>

            <div className="form-group">
              <label>
                <FaMapMarkerAlt /> Mark Location on Map
              </label>
              <div className="map-container">
                <MapContainer
                  center={[13.0827, 80.2707]}
                  zoom={10}
                  style={{ height: '100%', width: '100%' }}
                >
                  <TileLayer
                    url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                    attribution='&copy; OpenStreetMap contributors'
                  />
                  <LocationMarker position={position} setPosition={setPosition} />
                </MapContainer>
              </div>
              {position && (
                <p className="text-muted" style={{ fontSize: '12px' }}>
                  Location: {position[0].toFixed(4)}, {position[1].toFixed(4)}
                </p>
              )}
            </div>

            <div className="form-group">
              <label>Upload Image (Optional)</label>
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleImageChange}
                accept="image/*"
                style={{ display: 'none' }}
              />
              <div 
                className={`file-upload ${imagePreview ? 'has-file' : ''}`}
                onClick={() => fileInputRef.current?.click()}
              >
                {imagePreview ? (
                  <div>
                    <img src={imagePreview} alt="Preview" className="image-preview" />
                    <button 
                      type="button" 
                      className="btn btn-sm btn-danger mt-1"
                      onClick={(e) => { e.stopPropagation(); removeImage(); }}
                    >
                      <FaTimes /> Remove
                    </button>
                  </div>
                ) : (
                  <>
                    <FaUpload className="upload-icon" />
                    <p>Click to upload image</p>
                    <p className="text-muted" style={{ fontSize: '12px' }}>Max size: 5MB</p>
                  </>
                )}
              </div>
            </div>

            <div className="form-group">
              <label className="checkbox-label">
                <input
                  type="checkbox"
                  checked={agree}
                  onChange={(e) => setAgree(e.target.checked)}
                />
                <span style={{ marginLeft: '8px' }}>
                  I declare that the information provided is true to the best of my knowledge.
                </span>
              </label>
            </div>

            <button type="submit" className="btn btn-primary btn-lg" disabled={loading}>
              {loading ? 'Submitting...' : 'Submit Complaint'}
            </button>
          </form>
        </div>
      </main>
    </div>
  );
};

export default FileComplaint;
