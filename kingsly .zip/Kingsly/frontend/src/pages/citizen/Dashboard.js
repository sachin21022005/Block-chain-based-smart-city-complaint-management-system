import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import Sidebar from '../../components/Sidebar';
import { complaintsAPI } from '../../services/api';
import { toast } from 'react-toastify';
import { FaPlus, FaClipboardList, FaCheckCircle, FaClock, FaSpinner } from 'react-icons/fa';
import '../../components/Sidebar.css';
import './Dashboard.css';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:8000';

const Dashboard = () => {
  const [complaints, setComplaints] = useState([]);
  const [stats, setStats] = useState({
    total: 0,
    Pending: 0,
    Assigned: 0,
    Working: 0,
    Resolved: 0
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [complaintsRes, statsRes] = await Promise.all([
        complaintsAPI.getAll(),
        complaintsAPI.getStats()
      ]);
      setComplaints(complaintsRes.data);
      setStats(statsRes.data);
    } catch (error) {
      toast.error('Failed to fetch data');
    } finally {
      setLoading(false);
    }
  };

  const getStatusBadge = (status) => {
    const badges = {
      Pending: 'badge-pending',
      Assigned: 'badge-assigned',
      Working: 'badge-working',
      Resolved: 'badge-resolved',
      Rejected: 'badge-rejected'
    };
    return badges[status] || 'badge-pending';
  };

  if (loading) {
    return (
      <div className="dashboard-layout">
        <Sidebar />
        <main className="main-content">
          <div className="loading-container">
            <div className="spinner"></div>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="dashboard-layout">
      <Sidebar />
      <main className="main-content">
        <div className="page-header">
          <h1>My Dashboard</h1>
          <p>Track your complaints and their status</p>
        </div>

        {/* Stats Cards */}
        <div className="stats-grid">
          <div className="stat-card">
            <div className="stat-icon total">
              <FaClipboardList />
            </div>
            <div className="stat-info">
              <h3>{stats.total}</h3>
              <p>Total Complaints</p>
            </div>
          </div>
          <div className="stat-card">
            <div className="stat-icon pending">
              <FaClock />
            </div>
            <div className="stat-info">
              <h3>{stats.Pending}</h3>
              <p>Pending</p>
            </div>
          </div>
          <div className="stat-card">
            <div className="stat-icon working">
              <FaSpinner />
            </div>
            <div className="stat-info">
              <h3>{stats.Assigned + stats.Working}</h3>
              <p>In Progress</p>
            </div>
          </div>
          <div className="stat-card">
            <div className="stat-icon resolved">
              <FaCheckCircle />
            </div>
            <div className="stat-info">
              <h3>{stats.Resolved}</h3>
              <p>Resolved</p>
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="quick-actions">
          <Link to="/file-complaint" className="btn btn-primary">
            <FaPlus /> File New Complaint
          </Link>
        </div>

        {/* Complaints Table */}
        <div className="card">
          <div className="card-header">
            <h3>My Complaints</h3>
          </div>
          <div className="table-container">
            {complaints.length === 0 ? (
              <div className="empty-state">
                <FaClipboardList className="empty-icon" />
                <h3>No Complaints Yet</h3>
                <p>You haven't filed any complaints. Click the button above to file one.</p>
              </div>
            ) : (
              <table className="data-table">
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>Title</th>
                    <th>District</th>
                    <th>Status</th>
                    <th>Assigned To</th>
                    <th>Date</th>
                  </tr>
                </thead>
                <tbody>
                  {complaints.map((complaint) => (
                    <tr key={complaint._id}>
                      <td><code>{complaint._id.slice(-8)}</code></td>
                      <td>
                        <div className="complaint-title">
                          {complaint.imageId && (
                            <img 
                              src={`${API_URL}/api/image/${complaint.imageId}`} 
                              alt="" 
                              className="complaint-thumb"
                            />
                          )}
                          <span>{complaint.title}</span>
                        </div>
                      </td>
                      <td>{complaint.district}</td>
                      <td>
                        <span className={`badge ${getStatusBadge(complaint.status)}`}>
                          {complaint.status}
                        </span>
                      </td>
                      <td>{complaint.assignedOfficerName || '-'}</td>
                      <td>{new Date(complaint.createdAt).toLocaleDateString()}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </div>
      </main>
    </div>
  );
};

export default Dashboard;
