import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { FaSignOutAlt, FaUser } from 'react-icons/fa';
import './Navbar.css';

const Navbar = () => {
  const { user, logout } = useAuth();

  const getDashboardLink = () => {
    if (!user) return '/login';
    switch (user.role) {
      case 'admin':
        return '/admin/dashboard';
      case 'officer':
        return '/officer/dashboard';
      default:
        return '/dashboard';
    }
  };

  return (
    <nav className="navbar">
      <div className="container nav-content">
        <Link to="/" className="logo">
          <i className="fas fa-city"></i> SmartCity
        </Link>

        <div className="nav-links">
          <Link to="/">Home</Link>
          {user ? (
            <>
              <Link to={getDashboardLink()}>Dashboard</Link>
              <div className="user-menu">
                <FaUser className="user-icon" />
                <span>{user.name}</span>
                <button onClick={logout} className="btn-logout" title="Logout">
                  <FaSignOutAlt />
                </button>
              </div>
            </>
          ) : (
            <>
              <Link to="/login">Login</Link>
              <Link to="/register" className="btn btn-primary btn-sm">
                Register
              </Link>
            </>
          )}
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
