import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { 
  FaHome, 
  FaClipboardList, 
  FaPlus, 
  FaUsers, 
  FaSignOutAlt,
  FaChartBar
} from 'react-icons/fa';
import './Sidebar.css';

const Sidebar = () => {
  const { user, logout } = useAuth();
  const location = useLocation();

  const citizenLinks = [
    { to: '/dashboard', icon: <FaHome />, label: 'Dashboard' },
    { to: '/file-complaint', icon: <FaPlus />, label: 'File Complaint' }
  ];

  const officerLinks = [
    { to: '/officer/dashboard', icon: <FaClipboardList />, label: 'My Assignments' }
  ];

  const adminLinks = [
    { to: '/admin/dashboard', icon: <FaChartBar />, label: 'Dashboard' },
    { to: '/admin/officers', icon: <FaUsers />, label: 'Manage Officers' }
  ];

  const getLinks = () => {
    switch (user?.role) {
      case 'admin':
        return adminLinks;
      case 'officer':
        return officerLinks;
      default:
        return citizenLinks;
    }
  };

  const links = getLinks();

  return (
    <aside className="sidebar">
      <div className="sidebar-header">
        <Link to="/" className="sidebar-logo">
          <span className="logo-icon">🏛️</span>
          <span className="logo-text">SmartCity</span>
        </Link>
      </div>

      <div className="sidebar-user">
        <div className="user-avatar">
          {user?.name?.charAt(0).toUpperCase()}
        </div>
        <div className="user-info">
          <span className="user-name">{user?.name}</span>
          <span className="user-role">{user?.role}</span>
        </div>
      </div>

      <nav className="sidebar-nav">
        {links.map((link) => (
          <Link
            key={link.to}
            to={link.to}
            className={`nav-item ${location.pathname === link.to ? 'active' : ''}`}
          >
            {link.icon}
            <span>{link.label}</span>
          </Link>
        ))}
      </nav>

      <div className="sidebar-footer">
        <button onClick={logout} className="logout-btn">
          <FaSignOutAlt />
          <span>Logout</span>
        </button>
      </div>
    </aside>
  );
};

export default Sidebar;
