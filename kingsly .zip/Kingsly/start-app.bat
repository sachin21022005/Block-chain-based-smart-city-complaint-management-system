@echo off
title Smart Complaint System - Startup

echo ==========================================
echo    Smart Complaint System - Starting
echo ==========================================
echo.

:: Check if MongoDB is running
echo Checking MongoDB status...
tasklist /FI "IMAGENAME eq mongod.exe" 2>NUL | find /I /N "mongod.exe">NUL
if "%ERRORLEVEL%"=="0" (
    echo MongoDB is already running.
) else (
    echo MongoDB is not running. Please start MongoDB first!
    echo You can start it with: mongod --dbpath "your-data-path"
    echo.
    pause
    exit /b 1
)

echo.
echo ==========================================
echo Starting Backend Server (Port 8000)...
echo ==========================================
start "Smart Complaint - Backend" cmd /k "cd /d %~dp0backend && npm start"

:: Wait a moment for backend to initialize
timeout /t 3 /nobreak >nul

echo.
echo ==========================================
echo Starting Frontend Server (Port 3000)...
echo ==========================================
start "Smart Complaint - Frontend" cmd /k "cd /d %~dp0frontend && npm start"

echo.
echo ==========================================
echo    SERVERS STARTED SUCCESSFULLY!
echo ==========================================
echo.
echo Backend:  http://localhost:8000
echo Frontend: http://localhost:3000
echo.
echo Login Credentials:
echo ------------------
echo Admin:   admin@smartcomplaint.com / admin123
echo Officer: kumar@smartcomplaint.com / officer123
echo Citizen: citizen@example.com / citizen123
echo.
echo Press any key to close this window...
echo (The servers will continue running in their own windows)
pause >nul
