@echo off
title Smart Complaint System - Quick Start

echo ==========================================
echo    Smart Complaint System - Quick Start
echo ==========================================
echo.
echo NOTE: Make sure MongoDB is running before continuing!
echo.

echo Starting Backend Server (Port 8000)...
start "Smart Complaint - Backend" cmd /k "cd /d %~dp0backend && npm start"

:: Wait for backend to initialize
timeout /t 3 /nobreak >nul

echo Starting Frontend Server (Port 3000)...
start "Smart Complaint - Frontend" cmd /k "cd /d %~dp0frontend && npm start"

echo.
echo ==========================================
echo    SERVERS ARE STARTING...
echo ==========================================
echo.
echo Backend:  http://localhost:8000
echo Frontend: http://localhost:3000
echo.
echo Wait a few seconds for both servers to fully initialize,
echo then open http://localhost:3000 in your browser.
echo.
echo Login Credentials:
echo ------------------
echo Admin:   admin@smartcomplaint.com / admin123
echo Officer: kumar@smartcomplaint.com / officer123
echo Citizen: citizen@example.com / citizen123
echo.
echo Press any key to exit this launcher...
pause >nul
